export const MongoURI = "mongodb://localhost:27017/media";
export const Secret = "someSecret";